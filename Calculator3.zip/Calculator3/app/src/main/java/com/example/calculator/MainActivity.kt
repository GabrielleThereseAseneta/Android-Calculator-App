package com.example.calculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val output = findViewById<TextView>(R.id.lblOutput)
        val input = findViewById<TextView>(R.id.lblInput)
        val c = findViewById<Button>(R.id.btnC)
        val del = findViewById<Button>(R.id.btnDel)
        val percent = findViewById<Button>(R.id.btnPercent)
        val div = findViewById<Button>(R.id.btnDiv)
        val seven = findViewById<Button>(R.id.btn7)
        val eight = findViewById<Button>(R.id.btn8)
        val nine = findViewById<Button>(R.id.btn9)
        val mul = findViewById<Button>(R.id.btnMul)
        val four = findViewById<Button>(R.id.btn4)
        val five = findViewById<Button>(R.id.btn5)
        val six = findViewById<Button>(R.id.btn6)
        val sub = findViewById<Button>(R.id.btnSub)
        val one = findViewById<Button>(R.id.btn1)
        val two = findViewById<Button>(R.id.btn2)
        val three = findViewById<Button>(R.id.btn3)
        val add = findViewById<Button>(R.id.btnAdd)
        val zero = findViewById<Button>(R.id.btn0)
        val dot = findViewById<Button>(R.id.btnDot)
        val equals = findViewById<Button>(R.id.btnEquals)


        one.setOnClickListener {
            val inpTemp= input.text.toString()
            if(inpTemp.equals("0")){
                input.text="1"
            }
            else {
                input.text=inpTemp.plus("1")
            }
        }
        two.setOnClickListener {
            val inpTemp= input.text.toString()
            if(inpTemp.equals("0")){
                input.text="2"
            }
            else {
                input.text = inpTemp.plus("2")
            }
        }
        three.setOnClickListener {
            val inpTemp= input.text.toString()
            if(inpTemp.equals("0")){
                input.text="3"
            }
            else {
                input.text=inpTemp.plus("3")
            }
        }
        four.setOnClickListener {
            val inpTemp= input.text.toString()
            if(inpTemp.equals("0")){
                input.text="4"
            }
            else {
                input.text=inpTemp.plus("4")
            }
        }
        five.setOnClickListener {
            val inpTemp= input.text.toString()
            if(inpTemp.equals("0")){
                input.text="5"
            }
            else {
                input.text=inpTemp.plus("5")
            }
        }
        six.setOnClickListener {
            val inpTemp= input.text.toString()
            if(inpTemp.equals("0")){
                input.text="6"
            }
            else {
                input.text=inpTemp.plus("6")
            }
        }
        seven.setOnClickListener {
            val inpTemp= input.text.toString()
            if(inpTemp.equals("0")){
                input.text="7"
            }
            else {
                input.text=inpTemp.plus("7")
            }
        }
        eight.setOnClickListener {
            val inpTemp= input.text.toString()
            if(inpTemp.equals("0")){
                input.text="8"
            }
            else {
                input.text=inpTemp.plus("8")
            }
        }
        nine.setOnClickListener {
            val inpTemp= input.text.toString()
            if(inpTemp.equals("0")){
                input.text="9"
            }
            else {
                input.text=inpTemp.plus("9")
            }
        }
        zero.setOnClickListener {
            val inpTemp= input.text.toString()
            if(inpTemp.equals("0")){
                input.text="0"
            }
            else {
                input.text=inpTemp.plus("0")
            }
        }
        c.setOnClickListener {
            input.text = "0"
        }
        del.setOnClickListener {
            val inpTemp = input.text.toString()
            val outLen = inpTemp.length
            val outNew = inpTemp.subSequence(0,outLen-1)
            if(outLen ==1){
                input.text = "0"
            }
            else{
                input.text = outNew
            }
        }
        dot.setOnClickListener {
            val inpTemp = input.text.toString()
            if(!inpTemp.contains(".")){
                input.text = inpTemp.plus(".")
            }
        }
        percent.setOnClickListener {
            val inpTemp = (input.text.toString().toDouble())
            val outPercent = inpTemp/100
            output.text = "$outPercent"
        }
    }
}